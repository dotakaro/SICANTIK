<nav id="shortcuts">
	<h6><?php echo lang('cp_shortcuts_title'); ?></h6>
	<ul>
		<li><?php echo anchor('admin/polls/insert', lang('polls:new_poll_label'), 'class="add"') ?></li>
		<li><?php echo anchor('admin/polls', lang('polls:list_label')); ?></li>
	</ul>
	<br class="clear-both" />
</nav>
