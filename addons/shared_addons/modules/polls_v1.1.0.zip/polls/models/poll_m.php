<?php defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Poll model
 *
 * @author Victor Michnowicz
 * @category Modules
 * @todo Rember not to remove this file...
 */
class Poll_m extends MY_Model {}