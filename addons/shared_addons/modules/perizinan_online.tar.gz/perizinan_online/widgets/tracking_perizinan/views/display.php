<form method="get" action="<?php echo site_url('perizinan_online/verifikasi_izin'); ?>">
    <fieldset>
        <label for="no_pendaftaran">Untuk mengetahui status permohonan yang telah anda lakukan, masukan Nomor Pendaftaran anda : </label>
        <input type="text" name="no_pendaftaran" id="no_pendaftaran" placeholder="No Pendaftaran">
        <input type="submit" value="Lihat">
    <fieldset>
</form>