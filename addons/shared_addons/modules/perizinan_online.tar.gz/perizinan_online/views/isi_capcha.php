<?php
echo $img;
?>
<input type="hidden" value="<?php echo $word; ?>" id="isi_capca" name="isi_capca">