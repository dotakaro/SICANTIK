<h2><?php echo config_item('forums_title'); ?></h2>
<?php $this->load->view('partials/breadcrumbs'); ?>

<?php echo $template['module_body']; ?>