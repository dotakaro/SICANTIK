<h2>Pengaduan Online</h2>
<p>Data Pengaduan yang anda laporkan akan segera kami proses di Kantor Dinas Perizinan.</p>
<p>Berikut Data Pengaduan: 
<table width="100%">
    <tbody><tr>
        <td width="20%">Nama</td>
        <td>:</td>
        <td><b><?php echo $nama;?></b></td>
    </tr>
    <tr>
        <td>Alamat</td>
        <td>:</td>
        <td><b><?php echo $alamat;?></b></td>
    </tr>
    <tr>
        <td>Tanggal</td>
        <td>:</td>
        <td><b><?php echo $tanggal;?></b></td>
    </tr>
    <tr>
        <td>Deskripsi</td>
        <td>:</td>
        <td><b><?php echo $deskripsi_pengaduan;?></b></td>
    </tr>
</table>
</p>
            