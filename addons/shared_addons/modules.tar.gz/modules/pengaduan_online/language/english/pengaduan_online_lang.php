<?php
//messages
$lang['pengaduan_online:success']			=	'It worked';
$lang['pengaduan_online:error']			=	'It didn\'t work';
$lang['pengaduan_online:no_items']		=	'No Items';

//page titles
$lang['pengaduan_online:create']			=	'Create Item';
$lang['pengaduan_online:configurations']			=	'Configurations';

//labels
$lang['pengaduan_online:layanan_online']			=	'Layanan Online';
$lang['pengaduan_online:pengaduan_online']			=	'Pengaduan Online';
$lang['pengaduan_online:name']			=	'Name';
$lang['pengaduan_online:slug']			=	'Slug';
$lang['pengaduan_online:manage']			=	'Manage';
$lang['pengaduan_online:item_list']		=	'Item List';
$lang['pengaduan_online:view']			=	'View';
$lang['pengaduan_online:edit']			=	'Edit';
$lang['pengaduan_online:delete']			=	'Delete';

$lang['pengaduan_online:nama']			=	'Nama';
$lang['pengaduan_online:alamat']			=	'Alamat';
$lang['pengaduan_online:provinsi']			=	'Provinsi';
$lang['pengaduan_online:kabupaten']			=	'Kabupaten';
$lang['pengaduan_online:kecamatan']			=	'Kecamatan';
$lang['pengaduan_online:kelurahan']			=	'Kelurahan';
$lang['pengaduan_online:deskripsi_pengaduan']			=	'Deskripsi Pengaduan';

//buttons
$lang['pengaduan_online:custom_button']	=	'Custom Button';
$lang['pengaduan_online:items']			=	'Items';
?>