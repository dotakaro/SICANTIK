<?php
//messages
$lang['pengaduan_online_config:success']			=	'It worked';
$lang['pengaduan_online_config:error']			=	'It didn\'t work';
$lang['pengaduan_online_config:no_items']		=	'No Items';

//page titles
$lang['pengaduan_online_config:create']			=	'Create Item';
$lang['pengaduan_online:configurations']			=	'Configurations';

//labels
$lang['pengaduan_online_config:name']			=	'Name';
$lang['pengaduan_online_config:manage']			=	'Manage';
$lang['pengaduan_online_config:item_list']		=	'Item List';
$lang['pengaduan_online_config:view']			=	'View';
$lang['pengaduan_online_config:edit']			=	'Edit';
$lang['pengaduan_online_config:delete']			=	'Delete';

$lang['pengaduan_online_config:url_backoffice']			=	'URL Backoffice';
?>