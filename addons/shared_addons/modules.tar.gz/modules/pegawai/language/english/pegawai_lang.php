<?php
//messages
$lang['pegawai:success']			=	'It worked';
$lang['pegawai:error']			=	'It didn\'t work';
$lang['pegawai:no_items']		=	'No Items';

//page titles
$lang['pegawai:create']			=	'Create Item';

//labels
$lang['pegawai:name']			=	'Name';
$lang['pegawai:slug']			=	'Slug';
$lang['pegawai:manage']			=	'Manage';
$lang['pegawai:item_list']		=	'Item List';
$lang['pegawai:view']			=	'View';
$lang['pegawai:edit']			=	'Edit';
$lang['pegawai:delete']			=	'Delete';

//buttons
$lang['pegawai:custom_button']	=	'Custom Button';
$lang['pegawai:items']			=	'Items';
?>