<p class="forum_buttons">
<?php foreach (get_buttons() as $button): ?>
	<?php echo $button; ?>&nbsp;
<?php endforeach; ?>
</p>