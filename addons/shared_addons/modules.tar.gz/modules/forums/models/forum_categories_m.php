<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Forum_categories_m extends MY_Model
{
  protected $_table = 'forum_categories';

  public function __construct() {
    parent::__construct();
  }
}
?>