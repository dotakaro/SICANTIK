<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Forums Title
|--------------------------------------------------------------------------
|
| This will (be default) be visable on all the forum pages.
|
*/
$config['forums_title'] = 'Forums';