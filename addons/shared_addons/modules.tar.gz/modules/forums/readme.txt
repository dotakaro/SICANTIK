


PyroCMS v.2.2.x - Forum Module 1.5.0 - 9/9/2013
visit: https://github.com/wbc-mike/pyro_module_forums
Issues: https://github.com/wbc-mike/pyro_module_forums/issues
Contact: http://wildbluechicken.com/contact

Update from v1.0 for PyroCMS 2.1.x

----
PyroCMS v2.1.x Forum Module - 07-07-2012
visit: http://www.cavaencoreparlerdebits.fr

----
PyroCMS v1.3.2 Forum Module
The old PyroCMS v0.9.9.7 Forum upgrade

For more info contact us: 
http://semicolondev.com/contact
 
