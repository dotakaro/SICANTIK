<?php
class Forums extends Public_Controller {

  function __construct()
  {
    parent::__construct();
			
    $this->load->model('forums_m');
    $this->load->model('forum_categories_m');
    $this->load->model('forum_posts_m');

    $this->lang->load('forums');
    $this->load->config('forums');

    if(!Settings::get('forums_editor'))
      {
	$this->forums_m->add_setting();
      }

    $this->template->enable_parser_body(FALSE);

		$this->template->append_css('module::forums.css');
		$this->template->append_js('module::forums.js');

    $this->template->set_breadcrumb('Home', '/');
  }
	
	
  function index()
  {
    if( $forum_categories = $this->forum_categories_m->get_all() )
      {
	// Get list of categories
	foreach($forum_categories as &$category)
	  {
	    $category->forums = $this->forums_m->get_many_by('category_id', $category->id);
				
	    // Get a list of forums in each category
	    foreach($category->forums as &$forum)
	      {
		$forum->topic_count = $this->forum_posts_m->count_topics_in_forum( $forum->id );
		$forum->reply_count = $this->forum_posts_m->count_replies_in_forum( $forum->id );
		$forum->last_post = $this->forum_posts_m->last_forum_post($forum->id);
		if(!empty($forum->last_post))
		  {
		    $forum->last_post->author = $this->forum_posts_m->author_info($forum->last_post->author_id);
		  }
	      }
	  }
      }
	
    $data->forum_categories =& $forum_categories;
    $this->template->set_breadcrumb('Forums');
    $this->template->build('forum/index', $data);
  }


  function view($forum_id = 0, $offset = 0)
  {
    // Check if forum exists, if not 404
    ($forum = $this->forums_m->get($forum_id)) || show_404();

    // Pagination junk
    $per_page = '25';
    $pagination = create_pagination('forums/view/'.$forum_id, $this->forum_posts_m->count_topics_in_forum($forum_id), $per_page, 4);

    if($offset < $per_page)
      {
	$offset = 0;
      }
    $pagination['offset'] = $offset;
    // End Pagination

    // Get all topics for this forum
    $forum->topics = $this->forum_posts_m->get_topics_by_forum($forum_id, $offset, $per_page);
		
    // Get a list of posts which have no parents (topics) in this forum
    foreach($forum->topics as &$topic)
      {
	$topic->post_count = $this->forum_posts_m->count_posts_in_topic($topic->id);
	$topic->last_post = $this->forum_posts_m->last_topic_post($topic->id);

	if(!empty($topic->last_post))
	  {
	    $topic->last_post->author = $this->forum_posts_m->author_info($topic->last_post->author_id);
	  }
      }
		
    $data->forum =& $forum;
    $data->pagination = $pagination;

    $this->template->set_breadcrumb('Forums', 'forums');
    $this->template->set_breadcrumb($forum->title);
    $this->template->build('forum/view', $data); 
  }

  function unsubscribe($user_id, $topic_id)
  {
    $this->load->model('forum_subscriptions_m');
    $topic = $this->forum_posts_m->get($topic_id);
    $this->forum_subscriptions_m->delete_by(array('user_id' => $user_id, 'topic_id' => $topic_id));
    $data->topic =& $topic;
    $this->template->build('posts/unsubscribe', $data);
  }

}
?>