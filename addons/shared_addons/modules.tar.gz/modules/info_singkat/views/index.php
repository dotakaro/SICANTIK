<div id="info_singkat">
  <h3>info_singkat</h3>
  <ol>
    {{ info_singkat }}
    <li>{{ id }}</li>
    {{ /info_singkat }}
  </ol>
</div>