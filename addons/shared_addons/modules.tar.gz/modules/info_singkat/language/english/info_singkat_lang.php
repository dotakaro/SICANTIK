<?php
//messages
$lang['info_singkat:success']			=	'It worked';
$lang['info_singkat:error']			=	'It didn\'t work';
$lang['info_singkat:no_items']		=	'No Items';

//page titles
$lang['info_singkat:create']			=	'Create Item';

//labels
$lang['info_singkat:name']			=	'Name';
$lang['info_singkat:slug']			=	'Slug';
$lang['info_singkat:manage']			=	'Manage';
$lang['info_singkat:item_list']		=	'Item List';
$lang['info_singkat:view']			=	'View';
$lang['info_singkat:edit']			=	'Edit';
$lang['info_singkat:delete']			=	'Delete';
$lang['info_singkat:yes']			=	'Ya';
$lang['info_singkat:no']			=	'Tidak';
$lang['info_singkat:published']			=	'Dipublikasikan';
$lang['info_singkat:info_content']			=	'Isi Info';

//buttons
$lang['info_singkat:custom_button']	=	'Custom Button';
$lang['info_singkat:items']			=	'Items';
?>