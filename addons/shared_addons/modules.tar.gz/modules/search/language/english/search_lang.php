<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']      = 'Search';
$lang['search:results']    = 'Search results';

// messages
$lang['search:no_results'] = 'No results were found from the search keyword.';