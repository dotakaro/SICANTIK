<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']      = 'Pencarian';
$lang['search:results']    = 'Hasil Pencarian';

// messages
$lang['search:no_results'] = 'Tidak ada hasil yang ditemukan dari kata kunci pencarian.';