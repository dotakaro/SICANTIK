<?php
//messages
$lang['dasar_hukum:success']			=	'It worked';
$lang['dasar_hukum:error']			=	'It didn\'t work';
$lang['dasar_hukum:no_items']		=	'No Items';

//page titles
$lang['dasar_hukum:create']			=	'Create Item';

//labels
$lang['dasar_hukum:name']			=	'Name';
$lang['dasar_hukum:slug']			=	'Slug';
$lang['dasar_hukum:manage']			=	'Manage';
$lang['dasar_hukum:item_list']		=	'Item List';
$lang['dasar_hukum:view']			=	'View';
$lang['dasar_hukum:edit']			=	'Edit';
$lang['dasar_hukum:delete']			=	'Delete';
$lang['dasar_hukum:yes']			=	'Yes';
$lang['dasar_hukum:no']			=	'No';

$lang['dasar_hukum:nama_dasar_hukum']			=	'Nama Dasar Hukum';
$lang['dasar_hukum:pdf_dasar_hukum']			=	'PDF Dasar Hukum';

//buttons
$lang['dasar_hukum:custom_button']	=	'Custom Button';
$lang['dasar_hukum:items']			=	'Items';
?>