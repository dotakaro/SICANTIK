<form method="post" action="<?php echo site_url('perizinan_online/verifikasi_izin'); ?>">
    <fieldset>
        <label for="no_izin">Ketikan Nomor Izin yang ingin anda verifikasi : </label>
        <input type="text" name="no_izin" id="no_izin" size="60" placeholder="No Izin">
        <input type="submit" value="Verifikasikan">
    <fieldset>
</form>