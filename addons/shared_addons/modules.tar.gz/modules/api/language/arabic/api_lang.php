<?php 

$lang['api:recent_activity'] = 'آخر النشاطات';

$lang['api:overview'] = 'ملخص';
$lang['api:keys'] = 'المفاتيح';

$lang['api:method'] = 'الآلية';
$lang['api:params'] = 'المُعطيات';
$lang['api:api_key'] = 'مفتاح API';

$lang['api:no_logs']          = 'ليس هناك أية سجلات بعد.';

$lang['api:enable_api'] = 'حالة API';
$lang['api:enable_api_description'] = 'سيسمح لهذا لكل من لديه مفتاح API بطلب البيانات والحصول عليها. فعّل هذه الخدمة فقط إن كنت تعلم نتيجة ذلك.';

$lang['api:enable_user_keys'] = 'مفاتيح مستخدمي واجهة API';
$lang['api:enable_user_keys_description'] = 'سيسمح هذا للمستخدمين توليد مفاتيح خاصة بهم كي يتمكنوا من التفاعل مع واجهة API.';

$lang['api:key_message'] = 'رمز API الخاص بك هو %s — حافظ على <strong>سريته</strong>!';
$lang['api:generate_key'] = 'توليد مفتاح API';
