<div id="{module_name_l}">
  <h3>{module_name_l}</h3>
  <ol>
    {{ {module_name_l} }}
    <li>{{ id }}</li>
    {{ /{module_name_l} }}
  </ol>
</div>