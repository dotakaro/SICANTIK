PyroCMS Module Generator
========================

Created by [WARPAINT Media](http://warpaintmedia.ca/ "Created By WARPAINT Media").

[Live hosted application!](dev.warpaintmedia.ca/pyro-module-generator/ "PyroCMS Module Generator Website")

**Version 2.0**

[View Source On Github](https://github.com/james2doyle/pyro-module-generator "PyroCMS Module Generator On Github")

---

#### Genrated Modules

**Included in all generated modules is the following setup:**

* `ID` field by default
* `order` field by default
* functionality for drag and drop table order (add `ui-sortable-container` to `tbody` in admin index view)
* basic function for files included but commented out
* `_form_data` function for passing data to form views
* settings table included, but commented out
