<div class="block">
    <div class="block-title">
        <a class="right" href="{{ url:site}}">Kembali ke halaman utama</a>
        <h2>Survey Selesai</h2>
    </div>

    <div class="block-content">
        Terima kasih atas partisipasi anda dalam <strong><?php echo $survey['description'];?></strong>
    </div>
</div>