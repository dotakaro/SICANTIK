<?php
//messages
$lang['daftar_layanan:success']			=	'It worked';
$lang['daftar_layanan:error']			=	'It didn\'t work';
$lang['daftar_layanan:no_items']		=	'No Items';

//page titles
$lang['daftar_layanan:create']			=	'Create Item';

//labels
$lang['daftar_layanan:name']			=	'Name';
$lang['daftar_layanan:slug']			=	'Slug';
$lang['daftar_layanan:manage']			=	'Manage';
$lang['daftar_layanan:item_list']		=	'Item List';
$lang['daftar_layanan:view']			=	'View';
$lang['daftar_layanan:edit']			=	'Edit';
$lang['daftar_layanan:delete']			=	'Delete';
$lang['daftar_layanan:yes']			=	'Yes';
$lang['daftar_layanan:no']			=	'No';
$lang['daftar_layanan:jenis_izin']	=	'Jenis Izin';

//buttons
$lang['daftar_layanan:custom_button']	=	'Custom Button';
$lang['daftar_layanan:items']			=	'Items';
?>