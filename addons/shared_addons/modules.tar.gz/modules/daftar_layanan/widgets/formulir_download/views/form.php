
<ol>
	<li class="even">
		<label>Number to display</label>
		<?php echo form_input('limit', $options['limit']) ?>
	</li>
</ol>