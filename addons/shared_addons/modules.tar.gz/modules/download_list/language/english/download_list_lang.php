<?php
//messages
$lang['download_list:success']			=	'It worked';
$lang['download_list:error']			=	'It didn\'t work';
$lang['download_list:no_items']		=	'No Items';

//page titles
$lang['download_list:create']			=	'Create Item';

//labels
$lang['download_list:name']			=	'Name';
$lang['download_list:slug']			=	'Slug';
$lang['download_list:manage']			=	'Manage';
$lang['download_list:item_list']		=	'Item List';
$lang['download_list:view']			=	'View';
$lang['download_list:edit']			=	'Edit';
$lang['download_list:delete']			=	'Delete';
$lang['download_list:yes']			=	'Yes';
$lang['download_list:no']			=	'No';

//buttons
$lang['download_list:custom_button']	=	'Custom Button';
$lang['download_list:items']			=	'Items';
?>