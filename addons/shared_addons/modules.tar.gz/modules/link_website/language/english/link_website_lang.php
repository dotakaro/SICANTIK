<?php
//messages
$lang['link_website:success']			=	'It worked';
$lang['link_website:error']			=	'It didn\'t work';
$lang['link_website:no_items']		=	'No Items';

//page titles
$lang['link_website:create']			=	'Create Item';

//labels
$lang['link_website:name']			=	'Name';
$lang['link_website:slug']			=	'Slug';
$lang['link_website:manage']			=	'Manage';
$lang['link_website:item_list']		=	'Item List';
$lang['link_website:view']			=	'View';
$lang['link_website:edit']			=	'Edit';
$lang['link_website:delete']			=	'Delete';

//buttons
$lang['link_website:custom_button']	=	'Custom Button';
$lang['link_website:items']			=	'Items';
?>