<?php
//messages
$lang['portal_theme:success']			=	'It worked';
$lang['portal_theme:error']			=	'It didn\'t work';
$lang['portal_theme:no_items']		=	'No Items';

//page titles
$lang['portal_theme:create']			=	'Create Item';

//labels
$lang['portal_theme:name']			=	'Name';
$lang['portal_theme:slug']			=	'Slug';
$lang['portal_theme:manage']			=	'Manage';
$lang['portal_theme:item_list']		=	'Item List';
$lang['portal_theme:view']			=	'View';
$lang['portal_theme:edit']			=	'Edit';
$lang['portal_theme:delete']			=	'Delete';

//buttons
$lang['portal_theme:custom_button']	=	'Custom Button';
$lang['portal_theme:items']			=	'Items';
?>