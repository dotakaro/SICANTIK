<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of trstspermohonan
 *
 * @author Eva
 * Updated : 23 Aug 2010 (Agus N)
 *
 */
class tmpermohonan_trstspermohonan extends DataMapper {

    var $table = 'tmpermohonan_trstspermohonan';

    public function __construct() {
        parent::__construct();
    }

}
?>
