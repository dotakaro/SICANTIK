<?php
/**
 * Description of ajax
 *
 * @author alfaridi
 */

class ajax extends DataMapper {

    var $table = 'ajax';

    public function __construct() {
        parent::__construct();
    }
    
}
