<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of trdasar_hukum_trperizinan class
 *
 * @author  Dichi Al Faridi
 * @since   1.0
 *
 */

class trdasar_hukum_trperizinan extends DataMapper {

    var $table = "trdasar_hukum_trperizinan";

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of trdasar_hukum_trperizinan class
