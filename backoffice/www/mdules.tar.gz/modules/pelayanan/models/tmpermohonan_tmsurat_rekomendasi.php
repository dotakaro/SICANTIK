<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Rekomendasi class
 *
 * @author agusnur
 * Created : 27 Des 2010
 *
 */

class tmpermohonan_tmsurat_rekomendasi extends DataMapper {

    var $table = 'tmpermohonan_tmsurat_rekomendasi';

    public function __construct() {
        parent::__construct();
    }

}