<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Syarat Tambahan class
 *
 * @author Indra Halim
 * Created : 14 Mei 2015
 *
 */

class tmpermohonan_trsyarat_tambahan extends DataMapper {

    var $table = 'tmpermohonan_trsyarat_tambahan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
