<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Jenis class
 *
 * @author agusnur
 * Created : 28 Okt 2010
 *
 */

class tmpermohonan_trjenis_permohonan extends DataMapper {

    var $table = 'tmpermohonan_trjenis_permohonan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
