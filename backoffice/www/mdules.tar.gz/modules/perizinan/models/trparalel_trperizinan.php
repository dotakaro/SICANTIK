<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of trparalel_trperizinan class
 *
 * @author  agusnur
 * Created : 02 Aug 2010
 *
 */

class trparalel_trperizinan extends DataMapper {

    var $table = 'trparalel_trperizinan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of trparalel_trperizinan class
