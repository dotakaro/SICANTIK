<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of trkelompok_perizinan_trperizinan class
 *
 * @author  agusnur
 * Created : 02 Aug 2010
 *
 */

class trkelompok_perizinan_trperizinan extends DataMapper {
    
    var $table = 'trkelompok_perizinan_trperizinan';

    public function __construct() {
        parent::__construct();
    }


}

// This is the end of trkelompok_perizinan_trperizinan class
