<div id="content">
<?php

        echo "<img src=".base_url()."assets/css/".$app_folder."/images/home.jpg>";
?>
</div>
