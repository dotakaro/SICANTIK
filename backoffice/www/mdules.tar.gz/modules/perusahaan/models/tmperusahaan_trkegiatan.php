<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of tmperusahaan_trkegiatan class
 *
 * @author agusnur
 * Created : 08 Okt 2010
 *
 */

class tmperusahaan_trkegiatan extends DataMapper {

    var $table = 'tmperusahaan_trkegiatan';

    public function __construct() {
        parent::__construct();
    }

}
