<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of tmperusahaan class
 *
 * @author  Dichi Al Faridi
 * @since   1.0
 *
 */

class tmperusahaan_trkelurahan extends DataMapper {

    var $table = 'tmperusahaan_trkelurahan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of tmperusahaan class
