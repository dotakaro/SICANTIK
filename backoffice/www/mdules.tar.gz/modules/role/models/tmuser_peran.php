<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of user_role_mdl class
 *
 * @author  Dichi Al Faridi
 * @since   1.0
 *
 */

class tmuser_peran extends DataMapper {

    var $table = 'tmuser_peran';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user_role_mdl class
