<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of trperizinan_trproperty
 *
 * @author Eva
 */
class trperizinan_trproperty extends DataMapper {

    var $table = 'trperizinan_trproperty';
    
    public function __construct() {
        parent::__construct();
    }

}

?>
