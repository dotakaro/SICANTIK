<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Archive Syarat class
 *
 * @author agusnur
 * Created : 12 Dec 2010
 *
 */

class tmarchive_syarat extends DataMapper {

    var $table = 'tmarchive_syarat';

    public function __construct() {
        parent::__construct();
    }

}
