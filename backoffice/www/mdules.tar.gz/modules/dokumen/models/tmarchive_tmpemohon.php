<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Archive Pemohon class
 *
 * @author agusnur
 * Created : 08 Nov 2010
 *
 */

class tmarchive_tmpemohon extends DataMapper {

    var $table = 'tmarchive_tmpemohon';

    public function __construct() {
        parent::__construct();
    }

}
