<div id="content">
    <div class="post">
        <div class="title">
            <h2><center><?php echo $page_name; ?></center></h2>
        </div>
        <div class="entry">
            <table width="100%" border="0"  cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <table border="1" width="100%"  cellpadding="0" cellspacing="0">
                <tr>
                    <td width="35%" align="center" style="padding-top: 20px; padding-bottom: 20px;"><br>PEMERINTAH KABUPATEN BANTUL DINAS PERIZINAN<br>
                            Jl. Gadjah Mada No. 1 Bantul<br>
                            Telp. (0274) 367867<br></td>
                    <td width="30%" align="center" style="padding-top: 20px; padding-bottom: 20px;"><b>SKRD</b>
                        <br><br>
                            (SURAT KETETAPAN RETRIBUSI DAERAH)<br>
                            Masa Retribusi 	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 	hari<br>
                            &nbsp;&nbsp;&nbsp;Tahun 	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: 	<?php echo $tahun;?><br></td>
                    <td width="35%" align="center" style="padding-top: 20px; padding-bottom: 20px;"><br><br>No.Urut
                            123<br><br></td>
                </tr>

            </table>


        </td>
    </tr>
     <tr>
         <td> <table border="1" width="100%"  cellpadding="0" cellspacing="0">
                <tr><td>
                 <br>
                 <table border="0" width="100%" style="padding-left:20px;"  >
              
                <tr>
                    <td width="25%">Nama</td>
                    <td>: &nbsp; <?php echo $nama;?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>: &nbsp; <?php echo $alamat;?></td>
                </tr>
                <tr>
                    <td>NPWRD</td>
                    <td>:</td>
                </tr>
                <tr>
                    <td>Jenis Izin</td>
                    <td>: &nbsp; <?php echo $jenisizin;?></td>
                </tr>
             
                   
            </table>
                 <br>
            <table width="100%" border="1" cellpadding="0" cellspacing="0">
                <tr align="center">
                    <td width="5%"><b>No</b></td>
                <td><b>Kode</b></td>
                <td><b>Keterangan</b></td>
                <td><b>Jumlah (Rp)</b></td>
              </tr>
              <tr>
                <td align="center">1</td>
                <td>SKR-234</td>
                <td>Nilai retribusi</td>
                <td>&nbsp;</td>
              </tr>
          
           
            </table>
         
            <br>
            <p style="padding-left:20px;">
                Dengan Huruf        :
                <br><br>
                <b><u>Perhatian</u></b>
                <br>
                <ol>
                    <li> 	Harap Penyetoran dilakukan melalui Bank dengan menggunakan SKRD ini.</li>
                    <li>  	Apabila SKRD ini tidak atau kurang dibayar setelah lewat waktu paling lama 30 hari sejak SKRD ini dikenakan sanksi administrasi berupa bunga sebesar 2 % per bulan..</li>
                </ol>
            </p>
                    </td>
                </tr>
                </table>
        </td>
    </tr>
     <tr>
        <td>
            <table border="1" width="100%"  cellpadding="0" cellspacing="0">
                <tr><td>
            <p align="left" style="padding-left:700px;" ><br>
                Pada Tanggal    &nbsp;&nbsp;&nbsp;&nbsp;:        &nbsp; <?php echo $this->lib_date->mysql_to_human($tanggalmasuk);?>&nbsp;&nbsp;&nbsp;&nbsp;<br>
            Dikeluarkan di  &nbsp;&nbsp;&nbsp;:            &nbsp;Bantul&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
            <p align="center" style="padding-left:650px;">
            <b>KEPALA DINAS PERIZINAN</b><br>
            <b>KABUPATEN BANTUL</b>
            <br>
            <br>
            <br>
            <br>
            <br>
            <b><u>Drs. HELMI JAMHARIS, M.M.</u></b>
            <br><b>NIP. 490 024 735</b><br><br>
            </p>
            </p>
                </td></tr>
            </table>
        </td>


     </tr>
</table>
         
        </div>

        
       
    </div>
    <br style="clear: both;" />
</div>
