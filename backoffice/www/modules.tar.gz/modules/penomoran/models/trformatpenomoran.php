<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Class ini digunakan untuk listing format penomoran untuk daftar ulang
 *
 * @author  Sani
 * @since   1.0
 *
 */

class trformatpenomoran extends DataMapper {

    var $table = 'trformatpenomoran';    

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
