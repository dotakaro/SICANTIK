<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of tmpegawai_tmsurat_keputusan class
 *
 * @author agusnur
 * Created : 19 Dec 2010
 *
 */

class tmpegawai_tmsurat_keputusan extends DataMapper {

    var $table = 'tmpegawai_tmsurat_keputusan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of tmpegawai class
