<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of massage_mdl class
 *
 * @author  Yogi Cahyana
 * created : 31 Aug 2010
 *
 */

class tmpesan_trsumber extends DataMapper {

    var $table = 'tmpesan_trsumber_pesan';

    
    public function __construct() {
        parent::__construct();
    }

}

// This is the end of massage_mdl class
