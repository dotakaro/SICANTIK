<div id="content">
    <div class="post">
        <div class="title">
            <h2><?php echo $page_name; ?></h2>
        </div>
        <div class="entry">
        <fieldset id="half">
                <legend>Filter Data</legend>
            <?php echo form_open('permohonan/sk');
                  
            ?>

            <div id="statusRail">
                   <div id="leftRail">
               <?php
                    echo form_label('Tgl Permohonan Awal','d_tahun');
                ?>

                    </div>
             <div id="rightRail">
              <?php
                $periodeawal_input = array(
                'name'  => 'tgla',
                'value' => $tgla,
                'class' => 'input-wrc',
                'class' => 'monbulan'
                );
                echo form_input($periodeawal_input);
                ?>
              </div>
           </div>

           <div id="statusRail">
                   <div id="leftRail">
                <?php
                    echo form_label('Tgl Permohonan Akhir','d_tahun');
                ?>

                    </div>
             <div id="rightRail">
              <?php
                $periodeakhir_input = array(
                'name'  => 'tglb',
                'value' => $tglb,
                'class' => 'input-wrc',
                'class' => 'monbulan'
            );
            echo form_input($periodeakhir_input);
            ?>
              </div>
           </div>
      
                  <div id="statusRail">
              <div id="leftRail"></div>
              <div id="rightRail">
                <?php
                    $filter_data = array(
                        'name' => 'button',
                        'class' => 'button-wrc',
                        'content' => 'Filter',
                        'value' => 'Filter'
                    );

                    echo form_submit($filter_data);
                    ?>
              </div>
            </div>
            <?php
            echo form_close();
            ?>
        </fieldset>
        </div>
        <div class="entry">
            <table cellpadding="0" cellspacing="0" border="0" class="display" id="sk">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No Pendaftaran</th>
						<th>Pemohon</th>
                        <th>Jenis Izin</th>
						<th>Tanggal Permohonan</th>
						<th>Jenis Permohonan</th>
                        <th>No Surat</th>
                        <th>Tanggal Surat</th>
						<th>Status Cetak Surat Izin</th>
						<th width="70">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1;
                    $results = mysql_query($list);
                    while ($rows = mysql_fetch_assoc(@$results)){
                        $no_surat = $rows['no_surat'];
                        $tgl_surat = $rows['tgl_surat'];
                        $c_cetak = $rows['c_cetak'];
//                        $showed = FALSE;
//                        $c_cetak = NULL;
//                        $query_data = "SELECT b.c_skrd, b.status_bap,
//                        b.bap_id, d.tgl_surat, d.no_surat, d.c_cetak
//                        FROM tmbap_tmpermohonan a, tmbap b, tmpermohonan_tmsk c, tmsk d
//                        WHERE a.tmpermohonan_id = '".$rows['id']."'
//                        AND a.tmbap_id = b.id
//                        AND c.tmpermohonan_id = a.tmpermohonan_id
//                        AND c.tmsk_id = d.id";
//                        $hasil_data = mysql_query($query_data);
//                        while ($rows_data = mysql_fetch_assoc(@$hasil_data)){
//                            if($rows_data['status_bap'] === $c_bap) {
//                                $no_surat = $rows_data['no_surat'];
//                                $tgl_surat = $rows_data['tgl_surat'];
//                                $c_cetak = $rows_data['c_cetak'];
//                                $showed = TRUE;
//                            } else {
//                                $showed = FALSE;
//                            }
//                        }
//                        if($showed){
                        ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $rows['pendaftaran_id'];?></td>
                        <td><?php echo $rows['n_pemohon'];?></td>
                        <td><?php echo $rows['n_perizinan'];?></td>
                        <td>
                        <?php
                        if($rows['idjenis'] == '1') $tgl_permohonan = $rows['d_terima_berkas'];
                        else if($rows['idjenis'] == '2') $tgl_permohonan = $rows['d_perubahan'];
                        else if($rows['idjenis'] == '3') $tgl_permohonan = $rows['d_perpanjangan'];
                        else if($rows['idjenis'] == '4') $tgl_permohonan = $rows['d_daftarulang'];
                        if($tgl_permohonan){
                            if($tgl_permohonan != '0000-00-00') echo $this->lib_date->mysql_to_human($tgl_permohonan);
                        }
                        ?>
                        </td>
						<td><?php echo $rows['n_permohonan'];?></td>
                        <td><?php echo $no_surat;?></td>
                        <td><?php
                        if($tgl_surat){
                            if($tgl_surat != '0000-00-00') echo $this->lib_date->mysql_to_human($tgl_surat);
                        }
                        ?></td>
                        <td>
                            <?php
                                if($c_cetak){
                                    echo "<b>Dicetak ".$c_cetak." kali</b>";
                                } else {
                                    echo "Belum di-cetak";
                                }
                            ?>
                        </td>
                         <td>
                            <center>
                          <?php
                                $img_edit = array(
                                    'src' => base_url().'assets/images/icon/property.png',
                                    'alt' => 'Edit',
                                    'title' => 'Edit',
                                    'border' => '0',
                                );
                                $img_cetak = array(
                                    'src' => base_url().'assets/images/icon/clipboard.png',
                                    'alt' => 'Cetak Surat Izin',
                                    'title' => 'Cetak Surat Izin',
                                    'border' => '0',
                                );
                                $img_cetak2 = array(
                                    'src' => base_url().'assets/images/icon/clipboard-doc.png',
                                    'alt' => 'Cetak SK',
                                    'title' => 'Cetak SK',
                                    'border' => '0',
                                );
                                if($rows['c_status_bayar'] == '1' && $rows['trkelompok_perizinan_id'] == '4' || $rows['trkelompok_perizinan_id'] !== '4'  ){// kondisi jiga berbayar maka sk bisa di cetak jika sudah di bayar
                                    
                                echo anchor(site_url('permohonan/sk/cetak') .'/'. $rows['id'].'/'.$rows['idizin'], img($img_cetak),'target="_blank"')."&nbsp;";
                                if($rows['c_keputusan'] == '1'){
                                    echo anchor(site_url('permohonan/keputusan/cetak') .'/'. $rows['id'].'/'.$rows['idizin'], img($img_cetak2),'target="_blank"')."&nbsp;";
//                                    echo anchor(site_url('permohonan/keputusan/edit') .'/'. $rows['id'], img($img_edit))."&nbsp;";//Tidak dipakai, digantikan Jasper
                                }
                                }
                            ?>
                             </center>
                        </td>
                    </tr>
                    <?php
                        $i++;
//                        }
                    }
                    ?>
                <?php
//                    $i=1;
//
//                    foreach ($list as $data){
//                        $data->tmpemohon->get();
//                        $data->trperizinan->get();
//                        $data->tmsk->get();
//                        $bap = new tmbap();
//                        $bap->where_related($data)->get();
//                        if($bap->status_bap === $c_bap){
//                            $cetak_skrd = $bap->c_skrd;
                    ?>
<!--                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $data->pendaftaran_id;?></td>
                        <td><?php echo $data->tmpemohon->n_pemohon;?></td>
                        <td><?php echo $data->trperizinan->n_perizinan;?></td>
			<td>
                        <?php
                        if($data->d_entry){
                            if($data->d_entry != '0000-00-00') echo $this->lib_date->mysql_to_human($data->d_entry);
                        }
                        ?>
                        </td>
                        <td><?php echo $data->tmsk->no_surat;?></td>
                        <td>
                            <?php
                                if($data->tmsk->c_cetak){
                                    echo "<b>Dicetak ".$data->tmsk->c_cetak." kali</b>";
                                } else {
                                    echo "Belum di-cetak";
                                }
                            ?>
                        </td>
                         <td><center>
                          <?php
                                $img_edit = array(
                                    'src' => base_url().'assets/images/icon/property.png',
                                    'alt' => 'Edit',
                                    'title' => 'Edit',
                                    'border' => '0',
                                );
                                $img_cetak = array(
                                    'src' => base_url().'assets/images/icon/clipboard.png',
                                    'alt' => 'Cetak Surat Izin',
                                    'title' => 'Cetak Surat Izin',
                                    'border' => '0',
                                );
                                $img_cetak2 = array(
                                    'src' => base_url().'assets/images/icon/clipboard-doc.png',
                                    'alt' => 'Cetak SK',
                                    'title' => 'Cetak SK',
                                    'border' => '0',
                                );
//                                echo anchor(site_url('permohonan/sk/edit') .'/'. $data->id, img($img_edit))
//                                     ."&nbsp;";
//                                if($data->tmsk->c_status !== "1")
                                //if($cetak_skrd)
                                echo anchor(site_url('permohonan/sk/cetak') .'/'. $data->id, img($img_cetak))."&nbsp;";
                                if($data->trperizinan->c_keputusan == 1){
                                    echo anchor(site_url('permohonan/keputusan/cetak') .'/'. $data->id, img($img_cetak2))."&nbsp;";
                                    echo anchor(site_url('permohonan/keputusan/edit') .'/'. $data->id, img($img_edit))."&nbsp;";
                                }
                            ?>
                             </center>
                        </td>
                    </tr>-->
                    <?php
//                        $i++;
//                        }
//                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <br style="clear: both;" />
</div>
