 
    <div id="content">
    <div class="post">
        <div class="title">
            <h2><?php echo $page_name; ?></h2>
        </div>
        <div class="entry">
        <fieldset id="half">
            <legend>Data Permohonan</legend>
            <div id="statusRail" style="font-weight: bold">
              <div id="leftRail" class="bg-grid">
                <?php
                    echo form_label('No Pendaftaran','no_daftar');
                ?>
              </div>
              <div id="rightRail" class="bg-grid">
                <?php
                    echo $daftar->pendaftaran_id;
                ?>
              </div>
            </div>
            <div id="statusRail">
              <div id="leftRail">
                <?php
                    echo form_label('Nama','nama');
                ?>
              </div>
              <div id="rightRail">
                <?php
                    $daftar->tmpemohon->get();
                    echo $daftar->tmpemohon->n_pemohon;
                ?>
              </div>
            </div>
            <div id="statusRail">
              <div id="leftRail" class="bg-grid">
                <?php
                    echo form_label('Alamat','alamat');
                ?>
              </div>
              <div id="rightRail" class="bg-grid">
                <?php
                    echo $daftar->tmpemohon->a_pemohon;
                ?>
              </div>
            </div>
            <div id="statusRail">
              <div id="leftRail">
                <?php
                    echo form_label('Nama Izin','nama_izin');
                ?>
              </div>
              <div id="rightRail">
                <?php
                    $daftar->trperizinan->get();
                    echo $daftar->trperizinan->n_perizinan;
                ?>
              </div>
            </div>
        </fieldset>
        </div>
        <?php
        $attr = array('name' => 'form', 'id' => 'form','onsubmit' => 'return validasi()');
        echo form_open('permohonan/keputusan/' . $save_method, $attr);
        echo form_hidden('id_daftar', $id_daftar);
        echo form_hidden('id_surat', $id_surat);
        ?>
        <div class="entry">
            <div id="tabs">
                <ul>
                    <li><a href="#tabs-1">Data Pembuatan SK</a></li>
                </ul>
                <div id="tabs-1">
                    <div id="contentleft">
                        <div class="contentForm">
                            <?php
                                $norefer_input = array(
                                    'name' => 'no_surat',
                                    'value' => $no_surat,
                                    'id'    =>  'no_surat',
                                    'class' => 'input-wrc required'
                                );
                                echo form_label('No Surat *');
                                echo form_input($norefer_input);
                            ?>
                        </div>
                        <div class="contentForm">
                                <?php
                                $tglsk_input = array(
                                    'name' => 'tgl_surat',
                                    'value' => $tgl_surat,
                                    'class' => 'input-all required',
                                    'id' => 'inputTanggal'
                                );
                                echo form_label('Tanggal Surat');
                                echo form_input($tglsk_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $ket1_input = array(
                                    'name' => 'ket1',
                                    'value' => $ket1,
                                    'class' => 'input-wrc required'
                                );
                                echo form_label('1. Keterangan');
                                echo form_input($ket1_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $nama1_input = array(
                                    'name' => 'nama1',
                                    'value' => $nama1,
                                    'class' => 'input-wrc required'
                                );
                                echo form_label('Nama');
                                echo form_input($nama1_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $alamat1_input = array(
                                    'name' => 'alamat1',
                                    'value' => $alamat1,
                                    'class' => 'input-area-wrc required'
                                );
                                echo form_label('Alamat');
                                echo form_textarea($alamat1_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $ket2_input = array(
                                    'name' => 'ket2',
                                    'value' => $ket2,
                                    'class' => 'input-wrc required'
                                );
                                echo form_label('2. Keterangan');
                                echo form_input($ket2_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $nama2_input = array(
                                    'name' => 'nama2',
                                    'value' => $nama2,
                                    'class' => 'input-wrc required'
                                );
                                echo form_label('Nama');
                                echo form_input($nama2_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $alamat2_input = array(
                                    'name' => 'alamat2',
                                    'value' => $alamat2,
                                    'class' => 'input-area-wrc required'
                                );
                                echo form_label('Alamat');
                                echo form_textarea($alamat2_input);
                            ?>
                        </div>
                    </div>
                    <div id="contentright">
                        <div class="contentForm">
                            <?php
                                $content1_input = array(
                                    'name' => 'content1',
                                    'value' => $content1,
                                    'class' => 'input-area-wrc',
                                    'style' => 'min-width:300pt'
                                );
                                echo form_label('Content 1');
                                echo form_textarea($content1_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $content2_input = array(
                                    'name' => 'content2',
                                    'value' => $content2,
                                    'class' => 'input-area-wrc',
                                    'style' => 'min-width:300pt'
                                );
                                echo form_label('Content 2');
                                echo form_textarea($content2_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $content3_input = array(
                                    'name' => 'content3',
                                    'value' => $content3,
                                    'class' => 'input-area-wrc',
                                    'style' => 'min-width:300pt'
                                );
                                echo form_label('Content 3');
                                echo form_textarea($content3_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $salinan1_input = array(
                                    'name' => 'salinan1',
                                    'value' => $salinan1,
                                    'class' => 'input-wrc'
                                );
                                echo form_label('Salinan 1');
                                echo form_input($salinan1_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $salinan2_input = array(
                                    'name' => 'salinan2',
                                    'value' => $salinan2,
                                    'class' => 'input-wrc'
                                );
                                echo form_label('Salinan 2');
                                echo form_input($salinan2_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $salinan3_input = array(
                                    'name' => 'salinan3',
                                    'value' => $salinan3,
                                    'class' => 'input-wrc'
                                );
                                echo form_label('Salinan 3');
                                echo form_input($salinan3_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $salinan4_input = array(
                                    'name' => 'salinan4',
                                    'value' => $salinan4,
                                    'class' => 'input-wrc'
                                );
                                echo form_label('Salinan 4');
                                echo form_input($salinan4_input);
                            ?>
                        </div>
                        <div class="contentForm">
                            <?php
                                $salinan5_input = array(
                                    'name' => 'salinan5',
                                    'value' => $salinan5,
                                    'class' => 'input-wrc'
                                );
                                echo form_label('Salinan 5');
                                echo form_input($salinan5_input);
                            ?>
                        </div>
                    </div>
                    <br style="clear: both;" />
                </div>
            </div>
        </div>
        <div class="entry" style="text-align: center;">
            <?php
            $add_daftar = array(
                'name' => 'submit',
                'class' => 'submit-wrc',
                'content' => 'Simpan',
                'type' => 'submit',
                'value' => 'Simpan'
            );
            echo form_submit($add_daftar);
            echo "<span></span>";
            $cancel_daftar = array(
                'name' => 'button',
                'class' => 'button-wrc',
                'content' => 'Batal',
                'onclick' => 'parent.location=\''. site_url('permohonan/sk') . '\''
            );
            echo form_button($cancel_daftar);
            echo form_close();
            ?>
        </div>
    </div>
    <br style="clear: both;" />
</div>
