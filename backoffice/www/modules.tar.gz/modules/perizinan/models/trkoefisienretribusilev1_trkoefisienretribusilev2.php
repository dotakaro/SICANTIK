<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of tmpermohonan_trperizinan
 *
 * @author Yogi Cahyana
 */
class trkoefisienretribusilev1_trkoefisienretribusilev2 extends DataMapper {

    var $table = 'trkoefisienretribusilev1_trkoefisienretribusilev2';

    public function __construct() {
        parent::__construct();
    }

}
?>
