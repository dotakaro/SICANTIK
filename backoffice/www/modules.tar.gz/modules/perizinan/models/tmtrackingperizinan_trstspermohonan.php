<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Tracking & Status class
 *
 * @author agusnur
 * Created : 06 Sep 2010
 *
 */

class tmtrackingperizinan_trstspermohonan extends DataMapper {

    var $table = 'tmtrackingperizinan_trstspermohonan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
