<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Mohon Rekomendasi class
 *
 * @author agusnur
 * Created : 27 Des 2010
 *
 */

class tmpermohonan_tmsurat_permohonan extends DataMapper {

    var $table = 'tmpermohonan_tmsurat_permohonan';

    public function __construct() {
        parent::__construct();
    }

}
