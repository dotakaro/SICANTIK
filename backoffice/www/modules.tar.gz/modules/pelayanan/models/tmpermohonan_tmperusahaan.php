<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Perusahaan class
 *
 * @author agusnur
 * Created : 21 Okt 2010
 *
 */

class tmpermohonan_tmperusahaan extends DataMapper {

    var $table = 'tmpermohonan_tmperusahaan';

    public function __construct() {
        parent::__construct();
    }

}