<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Kelurahan class
 *
 * @author agusnur
 * Created : 10 Aug 2010
 *
 */

class tmpemohon_trkelurahan extends DataMapper {

    var $table = 'tmpemohon_trkelurahan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
