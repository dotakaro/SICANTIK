<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Duo Property Jenis Perizinan class
 *
 * @author agusnur
 * Created : 23 Aug 2010
 *
 */

class tmproperty_jenisperizinan_trproperty extends DataMapper {

    var $table = 'tmproperty_jenisperizinan_trproperty';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
