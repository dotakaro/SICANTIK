<?php defined('BASEPATH') or exit('No direct script access allowed');
/**
 * Modul untuk Create Survey
 *
 * @author       Indra
 * @website      http://indra.com
 * @package      com.indra.survey
 * @subpackage   
 * @copyright    MIT
 */
class survey extends Public_Controller
{

    /**
     * The constructor
     * @access public
     * @return void
     */
    public function __construct()
    {
      parent::__construct();
      $this->lang->load('survey');
      $this->load->model('survey_m');
      $this->template->append_css('module::survey.css');
    }
     /**
     * List all surveys
     *
     *
     * @access  public
     * @return  void
     */
     public function index()
     {
      // bind the information to a key
      $data['survey'] = (array)$this->survey_m->get_all();
      // Build the page
      $this->template->title($this->module_details['name'])
      ->build('index', $data);
    }

  }

/* End of file survey.php */