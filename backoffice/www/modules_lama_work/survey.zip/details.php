<?php defined('BASEPATH') or exit('No direct script access allowed');

class Module_Survey extends Module {

	public $version = '1.0';

	public function info()
	{
		return array(
			'name' => array(
				'en' => 'Survey'
				),
			'description' => array(
				'en' => 'Modul untuk Create Survey'
				),
			'frontend' => true,
			'backend' => true,
			'menu' => 'content', // You can also place modules in their top level menu. For example try: 'menu' => 'Survey',
			'sections' => array(
				'items' => array(
					'name' 	=> 'survey:items', // These are translated from your language file
					'uri' 	=> 'admin/survey',
					'shortcuts' => array(
						'create' => array(
							'name' 	=> 'survey:create',
							'uri' 	=> 'admin/survey/create',
							'class' => 'add'
							)
						)
					)
				)
			);
	}

	public function install()
	{
		$this->dbforge->drop_table('survey');
		//$this->db->delete('settings', array('module' => 'survey'));

		// $this->load->library('files/files');
		// Files::create_folder(0, 'survey');

		$survey = array(
			'id' => array(
				'type' => 'INT',
				'constraint' => '11',
				'auto_increment' => TRUE
				),
			'order' => array(
				'type' => 'INT',
				'constraint' => '11',
				'null' => true
				),
			'slug' => array(
	'type' => 'VARCHAR',
),
'description' => array(
	'type' => 'VARCHAR',
),
'open_date' => array(
	'type' => 'DATE',
),
'close_date' => array(
	'type' => 'VARCHAR',
),
'active' => array(
	'type' => 'INT',
),

			);

		// $survey_setting = array(
		// 	'slug' => 'survey_setting',
		// 	'title' => 'Survey Setting',
		// 	'description' => 'A Yes or No option for the Survey module',
		// 	'`default`' => '1',
		// 	'`value`' => '1',
		// 	'type' => 'select',
		// 	'`options`' => '1=Yes|0=No',
		// 	'is_required' => 1,
		// 	'is_gui' => 1,
		// 	'module' => 'survey'
		// 	);

		$this->dbforge->add_field($survey);
		$this->dbforge->add_key('id', TRUE);

		if($this->dbforge->create_table('survey') AND
		   //$this->db->insert('settings', $survey_setting) AND
			is_dir($this->upload_path.'survey') OR @mkdir($this->upload_path.'survey',0777,TRUE))
		{
			return TRUE;
		}
	}

	public function uninstall()
	{
		// $this->load->library('files/files');
		// $this->load->model('files/file_folders_m');
		// $folder = $this->file_folders_m->get_by('name', 'survey');
		// Files::delete_folder($folder->id);
		$this->dbforge->drop_table('survey');
		//$this->db->delete('settings', array('module' => 'survey'));
		{
			return TRUE;
		}
	}


	public function upgrade($old_version)
	{
		// Your Upgrade Logic
		return TRUE;
	}

	public function help()
	{
		// Return a string containing help info
		// You could include a file and return it here.
		return "No documentation has been added for this module.<br />Contact the module developer for assistance.";
	}
}
/* End of file details.php */
