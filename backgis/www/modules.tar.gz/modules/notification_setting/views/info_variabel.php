    <fieldset id="half">
        <legend>Variabel</legend>
        <div>
            <table style="width:100%;">
                <thead>
                    <th style="width:50%;text-align:left">Ke Pemohon</th>
                    <th style="width:50%;text-align:left">Ke Petugas</th>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {$nama_pemohon}
                        </td>
                        <td>
                            {$nama_pemohon}
                        </td>
                    </tr>
                    <tr>
                        <td>
                            {$telp_pemohon}
                        </td>
                        <td>
                            {$telp_pemohon}
                        </td>
                    </tr>
                    <tr>
                        <td>
                            {$no_pendaftaran}
                        </td>
                        <td>
                            {$no_pendaftaran}
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>{$nama_pegawai}</td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>{$nama_unitkerja}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </fieldset>