<script>
function conf()
{
    var x = confirm('Apakah anda yakin akan menghapusnya?');
    if (x==true)
    {
        return true;
    } else if (x==false) {
        return false;
    }
}

</script>
<div id="content">
    <div class="post">
        <div class="title">
            <h2><?php echo $page_name; ?></h2>
        </div>
        <fieldset id="half">
                <legend>Aktivitas Per Periode</legend>
            <?php echo form_open('log');
                  
            ?>
                <div id="statusRail">
                    <div id="leftRail">
            <?php
                  echo form_label('Tgl Pengecekan Awal','d_tahun');
            ?>
                    </div>

                    <div id="rightRail">
                         <?php
                $periodeawal_input = array(
                'name'  => 'tgla',
                'value' => $tgla,
                'class' => 'input-wrc',
                    'readOnly'=>TRUE,
                'class' => 'monbulan'
                );
                echo form_input($periodeawal_input);
                ?>
                    </div>
                </div>

      <div id="statusRail">
                    <div id="leftRail">
              <?php
                    echo form_label('Tgl Pengecekan Akhir','d_tahun');
                ?>
                    </div>

                    <div id="rightRail">
           <?php
                $periodeakhir_input = array(
                'name'  => 'tglb',
                'value' => $tglb,
                'class' => 'input-wrc',
                    'readOnly'=>TRUE,
                'class' => 'monbulan'
            );
            echo form_input($periodeakhir_input);
            ?>
                    </div>
        </div>

                  <div id="statusRail">
              <div id="leftRail"></div>
              <div id="rightRail">
                <?php
                    $filter_data = array(
                        'name' => 'button',
                        'class' => 'button-wrc',
                        'content' => 'Filter',
                        'value' => 'Filter'
                    );

                     $reset_data = array(
                                    'name' => 'button',
                                    'content' => 'Reset Filter',
                                    'value' => 'Reset Filter',
                                    'class' => 'button-wrc',
                                    );

                     $cetak_data = array(
                                    'name' => 'button',
                                    'content' => 'Cetak All',
                                    'value' => 'Cetak',
                                    'class' => 'button-wrc',
                                    'onclick' => 'parent.location=\''. site_url('rekapitulasi/realisasi/cetak_reportAll') . '\''
                    );

                    echo form_submit($filter_data);
                    echo form_reset($reset_data);
                    //echo form_button($cetak_data);
                    ?>
              </div>
            </div>
         
        </fieldset>
            <?php
            echo form_close();
        ?>
       <br>
<div class="entry">
           <table cellpadding="0" cellspacing="0" border="0" class="display" id="monitoring">
                <thead>
                    <tr>
                       <th>No</th>
                        <th>User</th>
                        <th>Module</th>
                        <th>Keterangan</th>
                        <th>Tanggal/Waktu</th>
                        <th>ID Permohonan</th>
                    </tr>
                </thead>
                <tbody>
               
                    <?php
              $i = NULL;
                $img_delete = array(
                                    'src' => 'assets/images/icon/cross.png',
                                    'alt' => 'Delete',
                                    'title' => 'Delete',
                                    'border' => '0',
                                );
                  foreach ($user as $dt)
                            {
                          $i++;
                        ?>
                    <tr>

                        <td align="center"><?php echo $i; ?></td>
                        <td ><?php 
					  $user = new user();
					  $id_user = $dt->user_id;
					  $user->get_by_id($id_user);
					  $realname = $user->realname;
					  echo $realname;
						?></td>
                        <td><?php 
					  
					  
					  $code = $dt->code;
					  switch ($code) {
							case "0":
								echo "Login/Logout";
								break;
							case "1":
								echo "Pendaftaran";
								break;
							case "2":
								echo "Entry Data";
								break;
							case "3":
								echo "Penjadwalan Tinjauan";
								break;
							case "4":
								echo "Entry Hasil Tinjauan";
								break;
							case "5":
								echo "BAP";
								break;
							case "6":
								echo "Rekomendasi";
								break;
							case "7":
								echo "Penetapan";
								break;
							case "8":
								echo "Pembayaran Retribusi";
								break;
							case "9":
								echo "Retribusi";
								break;
							default:
								echo "Cetak Izin";
						} ?></td>
                        <td ><?php echo $dt->message; ?></td>
                        <td><?php
                        $pecah = explode ("-",$dt->date_time);
                        $jam_ex = explode(" ",$pecah[2]);
                        echo ($jam_ex[0].'-'.$pecah[1].'-'.$pecah[0].' '.$jam_ex[1]);?></td>
                        <td>
                        <?php
                        //$selisih = abs(strtotime(date('Y-m-d'))-strtotime(substr($dt->action_date,0,10)));
                        //$bulan = floor($selisih/(60*60*24*30*3));
                        //if($bulan>1)
                        //{
                          //  echo anchor(site_url('log/hapus') .'/'. $dt->id, img($img_delete), ' onClick="return conf()"');
                       // }
                       // else
                       // {
                       //     echo "&nbsp;";
                       // }
					  	$permohonan = new tmpermohonan();
					  	$id_permohonan = $dt->tmpermohonan;
					  	$permohonan->get_by_id($id_permohonan);
					  	echo $pendaftaran_id = $permohonan->pendaftaran_id;
                        ?>
                        </td>


                    </tr><?php }?>

<!---------------------------------------------------------------------------------------------------.-->


                </tbody>
                <tfoot>
                    <tr>
                        <th>No</th>
                        <th>User</th>
                        <th>Module</th>
                        <th>Aksi</th>
                        <th>Tanggal</th>
                        <th>&nbsp;</th>
                    </tr>
                </tfoot>
            </table>
        </div>
        </div>
    </div>
    <br style="clear: both;" />
</div>
