<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of tmpetugas_trunitkerja class
 *
 * @author  Dichi Al Faridi
 * @since   1.0
 *
 */

class tmpegawai_trunitkerja extends DataMapper {

    var $table = 'tmpegawai_trunitkerja';

    public function __construct() {
        parent::__construct();
    }
}

// This is the end of tmpetugas_trunitkerja class
