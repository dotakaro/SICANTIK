<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of tmpegawai class
 *
 * @author agusnur
 * Created : 04 Sep 2010
 *
 */

class tmpegawai_tmsk extends DataMapper {

    var $table = 'tmpegawai_tmsk';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of tmpegawai class
