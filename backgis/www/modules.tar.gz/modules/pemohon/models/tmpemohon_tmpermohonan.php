<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Pemohon class
 *
 * @author agusnur
 * Created : 21 Okt 2010
 *
 */

class tmpemohon_tmpermohonan extends DataMapper {

    var $table = 'tmpemohon_tmpermohonan';

    public function __construct() {
        parent::__construct();
    }

}