<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Syarat class
 *
 * @author agusnur
 * Created : 13 Aug 2010
 *
 */

class tmpermohonan_trsyarat_perizinan extends DataMapper {

    var $table = 'tmpermohonan_trsyarat_perizinan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
