<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Tracking class
 *
 * @author agusnur
 * Created : 06 Sep 2010
 *
 */

class tmpermohonan_tmtrackingperizinan extends DataMapper {

    var $table = 'tmpermohonan_tmtrackingperizinan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
