<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Prasarana class
 *
 * @author agusnur
 * Created : 02 Nov 2010
 *
 */

class tmpermohonan_tmproperty_prasarana extends DataMapper {

    var $table = 'tmpermohonan_tmproperty_prasarana';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
