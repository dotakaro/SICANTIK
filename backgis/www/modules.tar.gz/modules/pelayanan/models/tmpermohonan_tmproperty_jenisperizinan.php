<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of Permohonan & Property class
 *
 * @author agusnur
 * Created : 23 Aug 2010
 *
 */

class tmpermohonan_tmproperty_jenisperizinan extends DataMapper {

    var $table = 'tmpermohonan_tmproperty_jenisperizinan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
