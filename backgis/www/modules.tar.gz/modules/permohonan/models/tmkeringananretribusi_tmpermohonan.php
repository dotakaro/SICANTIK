<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class tmkeringananretribusi_tmpermohonan extends DataMapper {

    var $table = 'tmkeringananretribusi_tmpermohonan';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
