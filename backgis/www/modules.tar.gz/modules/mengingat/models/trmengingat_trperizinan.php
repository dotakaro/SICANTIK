<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of trmengingat_trperizinan class
 *
 * @author  agusnur
 * Created : 19 Dec 2010
 *
 */

class trmengingat_trperizinan extends DataMapper {

    var $table = "trmengingat_trperizinan";

    public function __construct() {
        parent::__construct();
    }

}