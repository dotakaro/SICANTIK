<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of tmpermohonan_trperizinan
 *
 * @author Yogi Cahyana
 */
class trkoefesientarifretribusi_trkoefisienretribusilev1 extends DataMapper {

    var $table = 'trkoefesientarifretribusi_trkoefisienretribusilev1';

    public function __construct() {
        parent::__construct();
    }

}
?>
