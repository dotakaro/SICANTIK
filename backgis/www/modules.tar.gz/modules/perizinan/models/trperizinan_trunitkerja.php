<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of trperizinan_trunitkerja class
 *
 * @author  agusnur
 * Created : 03 Aug 2010
 *
 */

class trperizinan_trunitkerja extends DataMapper {

    var $table = 'trperizinan_trunitkerja';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of trperizinan_trunitkerja class
