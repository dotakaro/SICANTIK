<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of trproperty_details class
 *
 * @author  Dichi Al Faridi
 * @since   1.0
 *
 */

class trproperty_details extends DataMapper {

    var $table = "trproperty_details";

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of trproperty_details class
