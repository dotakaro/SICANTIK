<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of tmproperty_klasifikasi_trkoefesientarifretribusi
 *
 * @author agusnur
 * Created : 01 Nov 2010
 *
 */

class tmproperty_klasifikasi_trkoefesientarifretribusi extends DataMapper {

    var $table = 'tmproperty_klasifikasi_trkoefesientarifretribusi';

    public function __construct() {
        parent::__construct();
    }

}

// This is the end of user class
