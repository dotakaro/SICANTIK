<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'البحث';
$lang['search:results']          = 'نتائج البحث';

// messages
$lang['search:no_results']            = 'لا يوجد أية نتائج للبحث بهذه الكلمات.';
