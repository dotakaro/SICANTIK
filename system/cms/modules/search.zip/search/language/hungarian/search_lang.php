<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Keresés';
$lang['search:results']          = 'Keresési eredmények';

// messages
$lang['search:no_results']       = 'Nincs eredmény az adott kifejezésre.';

/* End of file search_lang.php */