<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Cerca';
$lang['search:results']          = 'Risultati ricerca';

// messages
$lang['search:no_results']            = 'Non sono stati trovati risultati con i termini di ricerca inseriti.';