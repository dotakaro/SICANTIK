<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = '搜尋';
$lang['search:results']          = '搜尋結果';

// messages
$lang['search:no_results']       = '搜尋這些字詞，沒有找到結果。';