<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Etsi';
$lang['search:results']          = 'Hakutulokset';

// messages
$lang['search:no_results']            = 'Annetulla hakusanalla ei löytynyt yhtään hakutulosta.';