<?php defined('BASEPATH') or exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Αναζήτηση';
$lang['search:results']          = 'Αποτελέσματα Αναζήτησης';

// messages
$lang['search:no_results']            = 'Δεν υπάρχουν αποτελέσματα με αυτούς τους όρους αναζήτησης.';