<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Buscar';
$lang['search:results']          = 'Resultados de la Búsqueda';

// messages
$lang['search:no_results']            = 'No se encontraron resultados para esta búsqueda.';