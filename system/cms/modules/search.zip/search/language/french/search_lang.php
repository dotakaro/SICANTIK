<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Recherche';
$lang['search:results']          = 'Résultats de Recherche';

// messages
$lang['search:no_results']            = 'Aucun résultat n\'a été trouvé avec ces termes de recherche.';