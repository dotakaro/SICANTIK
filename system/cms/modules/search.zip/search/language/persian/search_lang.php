<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'جستجو';
$lang['search:results']          = 'نتایج جستجو';

// messages
$lang['search:no_results']            = 'هیچ نتیجه ای برای این جستجو یافت نشد.';