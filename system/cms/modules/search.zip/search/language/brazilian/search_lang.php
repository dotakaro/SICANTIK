<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Pesquisar';
$lang['search:results']          = 'Resultados da Pesquisa';

// messages
$lang['search:no_results']            = 'Nenhum resultado encontrado para esta pesquisa.';