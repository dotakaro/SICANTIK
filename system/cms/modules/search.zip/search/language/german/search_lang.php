<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['search:index']            = 'Suche';
$lang['search:results']          = 'Suchresultate';

// messages
$lang['search:no_results']            = 'Für diese Suchbegriffe konnte nichts gefunden werden.';